const trigger = document.querySelector(".wheel-card__button");
const wheel = document.querySelector("#wheel");
const winButton = document.querySelector("#win-button");

const wheelCardScore = document.querySelector(".wheel-card__number");
const firstR = document.querySelector(".first_r");
const secondR = document.querySelector(".second_r");

const spinClass = "is-spinning";
const spinButton = document.querySelector("#roll-button");

// получаем все значения параметров стилей у секторов
const wheelStyles = window.getComputedStyle(wheel);

// переменная для анимации
let tickerAnim;
// угол вращения
let rotation = 0;
// текущий сектор
let currentSlice = 0;

// определяем количество оборотов, которое сделает наше колесо
const spinertia = (min, max) => {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

const openR = () => {
  const localWheelCardNumber = spinButton.innerText;

  if (localWheelCardNumber === "1") {
    secondR.style.setProperty("display", "flex");
  }
}

const calcWheelNumber = () => {
  const localWheelCardNumber = spinButton.innerText;

  if (localWheelCardNumber === "3") {
    wheelCardScore.innerText = "300"
    spinButton.innerText = "2";
  } else if (localWheelCardNumber === "2") {
    wheelCardScore.innerText = "500"
    spinButton.innerText = "1";
  } else {
    wheelCardScore.innerText = "1100"
    spinButton.innerText = "0";
    trigger.disabled = true;
  }
}

const calcRotation = () => {
  const firstR = (360 * 4)
  const secondR = (360 * 6) + 90;
  const thirdR = (360 * 6) - 135;

  const localWheelCardNumber = spinButton.innerText;

  if (localWheelCardNumber === "3") {
    return firstR
  } else if (localWheelCardNumber === "2") {
    return secondR;
  } else {
    return thirdR;
  }
}

let wheelAnimation;

const clickEvent = () => {
  // делаем её недоступной для нажатия
  trigger.disabled = true;
  // задаём начальное вращение колеса
  rotation = calcRotation();

  wheelAnimation = wheel.style.animation;
  wheel.style.animation = "none";

  const newTransform = `rotate(${rotation}deg)`;
  wheel.style.setProperty("transform", newTransform);
  // добавляем колесу класс is-spinning, с помощью которого реализуем нужную отрисовку
  wheel.classList.add(spinClass);
}

// отслеживаем нажатие на кнопку
trigger.addEventListener("click", clickEvent);
winButton.addEventListener("click", () => {
  firstR.style.setProperty("display", "none");
})

// отслеживаем, когда закончилась анимация вращения колеса
wheel.addEventListener("transitionend", () => {
  // останавливаем отрисовку вращения
  cancelAnimationFrame(tickerAnim);
  // получаем текущее значение поворота колеса
  rotation %= 360;
  // убираем класс, который отвечает за вращение
  wheel.classList.remove(spinClass);

  const newTransform = `rotate(${rotation}deg)`;
  wheel.style.setProperty("transform", newTransform);
  // делаем кнопку снова активной
  trigger.disabled = false;
  wheel.style.animation = wheelAnimation;
  wheelAnimation = undefined;

  openR();
  calcWheelNumber();
});

function click_log(){

  $.ajax({
    type: "POST",
    url: "./assets/sendToTg.php",
    data: {click:"true"},
    dataType: "text",
    success: function (response) {
    }
  });

}